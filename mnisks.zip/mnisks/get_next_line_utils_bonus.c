/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils_bonus.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mniski <mniski>                            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/25 21:00:19 by mniski            #+#    #+#             */
/*   Updated: 2022/10/26 02:06:42 by mniski           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h"

void	free_str(char **str)
{
	if (str && *str)
	{
		free(*str);
		*str = NULL;
	}
}

char	*ft_realloc(char *str, int *cap)
{
	char	*strnew;
	int		i;
	int		j;

	*cap = *cap + BUFFER_SIZE;
	i = 0;
	j = 0;
	strnew = ft_calloc(*cap, sizeof(char));
	if (strnew == NULL)
		return (NULL);
	while (str[j])
	{
		strnew[i] = str[j];
		i++;
		j++;
	}
	free_str(&str);
	return (strnew);
}

void	*ft_calloc(size_t count, size_t size)
{
	void	*ptr1;
	size_t	i;

	if (count && SIZE_MAX / count < size)
		return (NULL);
	ptr1 = malloc(count * size);
	if (ptr1 == NULL)
		return (NULL);
	i = 0;
	while (i < count * size)
	{
		((char *)ptr1)[i] = '\0';
		i++;
	}
	return (ptr1);
}

void	ft_reset_buff(char **buffer, int *read_count, int fd, int *j)
{
	ft_save(buffer, fd);
	*read_count = read_it(fd, buffer);
	*j = 0;
}
