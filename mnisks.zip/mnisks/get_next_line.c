/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ohanchak <ohanchak@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/25 21:00:16 by mniski            #+#    #+#             */
/*   Updated: 2022/10/26 18:58:41 by ohanchak         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char	*ft_mainloop(int fd, char **buffer, char *output, int read_count)
{
	int	i;
	int	j;
	int	cap;

	i = 0;
	j = 0;
	cap = BUFFER_SIZE + 1;
	while (buffer[fd][j] != '\n' && read_count > 0)
	{
		output[i] = buffer[fd][j];
		i++;
		j++;
		if (buffer[fd][j] == '\0')
		{
			ft_reset_buff(buffer, &read_count, fd, &j);
			output = ft_realloc(output, &cap);
		}
	}
	if (buffer[fd][j] == '\n')
	{
		output[i] = '\n';
		ft_save(buffer, fd);
	}
	return (output);
}

int	read_it(int fd, char **buffer)
{
	int	i;

	i = 1;
	if (buffer[fd][0] == '\0')
		i = read(fd, buffer[fd], BUFFER_SIZE);
	return (i);
}

void	ft_save(char **buffer, int fd)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (buffer[fd][i] && buffer[fd][i] != '\n')
		i++;
	if (buffer[fd][i] == '\n')
	{
		i++;
		while (buffer[fd][i])
		{
			buffer[fd][j] = buffer[fd][i];
			j++;
			i++;
		}
	}
	while (j < BUFFER_SIZE)
	{
		buffer[fd][j] = '\0';
		j++;
	}
}

void	*ft_fail(char *output, char **buffer, int fd)
{
	free_str(&buffer[fd]);
	free_str(&output);
	return (NULL);
}

char	*get_next_line(int fd)
{
	static char	*buffer[1024];
	char		*output;
	int			i;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	if (buffer[fd] == NULL)
		buffer[fd] = ft_calloc(BUFFER_SIZE + 1, sizeof(char));
	if (buffer[fd] == NULL)
		return (NULL);
	i = read_it(fd, buffer);
	output = ft_calloc(BUFFER_SIZE + 1, sizeof(char));
	if (output == NULL)
		return (NULL);
	if (i <= 0)
		return (ft_fail(output, buffer, fd));
	output = ft_mainloop(fd, buffer, output, i);
	return (output);
}
