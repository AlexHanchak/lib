/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_bonus.h                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mniski <mniski>                            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/25 21:00:30 by mniski            #+#    #+#             */
/*   Updated: 2022/10/26 02:06:20 by mniski           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_BONUS_H
# define GET_NEXT_LINE_BONUS_H

# include <fcntl.h>
# include <stddef.h>
# include <unistd.h>
# include <stdlib.h>
# include <stdio.h>
# include <limits.h>

# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 6
# endif

void	free_str(char **str);
size_t	ft_strlen(const char *s);
char	*ft_realloc(char *str, int *n);
void	*ft_calloc(size_t count, size_t size);
void	ft_bzero(void *s, size_t n);
void	*ft_fail(char *output, char **buffer, int fd);
char	*get_next_line(int fd);
void	ft_save(char **save, int fd);
int		read_it(int fd, char **buffer);
char	*ft_mainloop(int fd, char **buffer, char *output, int read_count);
void	ft_reset_buff(char **buffer, int *read_count, int fd, int *j);

#endif